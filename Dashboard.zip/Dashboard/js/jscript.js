function social(){
 	document.getElementById("changeName").innerHTML ="Bar";
 document.getElementById('myChart1').style.display = "none";
 document.getElementById('myChart2').style.display = "none";
 document.getElementById('myChart').style.display = "block";
 document.getElementById('myChart3').style.display = "none";
var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(255, 206, 86, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)',
                'rgba(255, 159, 64, 0.8)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
	
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
}

function social1(){
	document.getElementById('myChart').style.display = "none";
    document.getElementById('myChart2').style.display = "none";
	document.getElementById('myChart1').style.display = "block";
	document.getElementById('myChart3').style.display = "none";
  	document.getElementById("changeName").innerHTML ="Pie";
	 
	
	var ctx = document.getElementById('myChart1').getContext('2d');
	var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(255, 206, 86, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)',
                'rgba(255, 159, 64, 0.8)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
	
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
}

function social2(){
	 	document.getElementById("changeName").innerHTML ="Line";
	
document.getElementById('myChart').style.display = "none";
 document.getElementById('myChart1').style.display = "none";
	document.getElementById('myChart2').style.display = "block";
	document.getElementById('myChart3').style.display = "none";
var ctx = document.getElementById('myChart2').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(255, 206, 86, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)',
                'rgba(255, 159, 64, 0.8)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
	
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
}

function social3(){
	 	document.getElementById("changeName").innerHTML ="Polar";
	
document.getElementById('myChart').style.display = "none";
 document.getElementById('myChart1').style.display = "none";
	document.getElementById('myChart2').style.display = "none";
	document.getElementById('myChart3').style.display = "block";
 
var ctx = document.getElementById('myChart3').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'polarArea',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.7)',
                'rgba(54, 162, 235, 0.7)',
                'rgba(255, 206, 86, 0.7)',
                'rgba(75, 192, 192, 0.7)',
                'rgba(153, 102, 255, 0.7)',
                'rgba(255, 159, 64, 0.7)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
	
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
}


var table = document.getElementsByTagName("table");
function tabletyp(){
	for(i =0; i< table.length; i++){
	document.getElementsByClassName("changeTbl")[i].classList.add("table-bordered");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-striped");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-condensed");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-hover");
	document.getElementsByClassName("changeTbl")[i].classList.remove("tableHoverDark");
	}
}
function tabletyp1(){
	for(i =0; i< table.length; i++){
	document.getElementsByClassName("changeTbl")[i].classList.add("table-hover");
	}
}

function tabletyp4(){
	
	for(i =0; i< table.length; i++){
	document.getElementsByClassName("changeTbl")[i].classList.add("tableHoverDark");
	}
}

function tabletyp2(){
	for(i =0; i< table.length; i++){
	document.getElementsByClassName("changeTbl")[i].classList.add("table-condensed");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-hover");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-striped");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-bordered");
	document.getElementsByClassName("changeTbl")[i].classList.remove("tableHoverDark");
	}
}

function tabletyp3(){
	for(i =0; i< table.length; i++){
	document.getElementsByClassName("changeTbl")[i].classList.add("table-striped");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-hover");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-condensed");
	document.getElementsByClassName("changeTbl")[i].classList.remove("table-bordered");
	document.getElementsByClassName("changeTbl")[i].classList.remove("tableHoverDark");
	}
}

function tableDark(){
	for(i =0; i< table.length; i++){
		document.getElementsByClassName("changeTbl")[i].classList.add("table-dark");
		document.getElementsByClassName("changeTbl")[i].classList.add("tbldark");
		document.getElementsByClassName("changeTbl")[i].classList.remove("table-white");
		document.getElementsByClassName("changeTbl")[i].classList.remove("table-hover");
		document.getElementById("dark").style.display='none';
		document.getElementById("light").style.display='block';
		document.getElementById("hover").style.display='none';
		document.getElementById("hoverD").style.display='block';
	}
}

function tableLight(){
	for(i =0; i< table.length; i++){	
		document.getElementsByClassName("changeTbl")[i].classList.add("table-white");
		document.getElementsByClassName("changeTbl")[i].classList.remove("table-dark");
		document.getElementsByClassName("changeTbl")[i].classList.remove("tbldark");
		document.getElementsByClassName("changeTbl")[i].classList.remove("tableHoverDark");
		document.getElementById("dark").style.display='block';
		document.getElementById("light").style.display='none';
		document.getElementById("hover").style.display='block';
		document.getElementById("hoverD").style.display='none';
	}
}
